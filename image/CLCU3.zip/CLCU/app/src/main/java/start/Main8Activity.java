package start;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.clcu.R;

public class Main8Activity extends AppCompatActivity {

//    public void setShownWeekCount(int count) {
//
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
//        setShownWeekCount(1);
    }


}
