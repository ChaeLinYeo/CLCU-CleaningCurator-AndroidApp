package start;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.clcu.R;

public class Main6Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
    }
}
