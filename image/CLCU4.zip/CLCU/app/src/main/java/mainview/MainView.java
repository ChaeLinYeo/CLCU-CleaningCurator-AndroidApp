package mainview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.clcu.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainView extends AppCompatActivity{

    private FragmentManager fragmentManager = getSupportFragmentManager();

    //메뉴 4버튼에 들어갈 fragment
    private Main9Activity frag_home = new Main9Activity();
    private Main10Activity frag_calendar = new Main10Activity();
    private Main11Activity frag_search = new Main11Activity();
    private Main14Activity frag_star = new Main14Activity();


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_view);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            ;

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.bottom_homeItem:{
                        break;
                    }
                    case R.id.bottom_calendarItem:{
                        break;
                    }
                    case R.id.bottom_searchItem:{
                        break;
                    }
                    case R.id.bottom_starItem:{
                        break;
                    }

                }
                return true;
            }

        }
    }
}